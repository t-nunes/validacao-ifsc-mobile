import styled from "styled-components/native";

export const Wrapper = styled.TextInput`
  width: 100%;
  flex-grow: 1;
  padding: 15px;
  background-color: #ddd;
`;
