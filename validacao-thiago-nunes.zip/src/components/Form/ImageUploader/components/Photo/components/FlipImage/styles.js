import styled from 'styled-components/native';

export const Wrapper = styled.TouchableOpacity`
  align-self: flex-end;
  align-items: center;
  margin: 15px;
`;
