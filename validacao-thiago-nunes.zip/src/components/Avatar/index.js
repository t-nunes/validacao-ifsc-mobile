import React from 'react'
import {SafeAreaView, Text} from 'react-native';

function Avatar() {
  return (
    <SafeAreaView>
      <Text>oi</Text>
    </SafeAreaView>
  )
}

export default Avatar;
