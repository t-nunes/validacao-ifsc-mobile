export default {
  headerStyle: {
    backgroundColor: '#000'
  }
};
