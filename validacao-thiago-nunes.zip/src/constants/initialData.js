export const CONTACTS = [
  { id: 'CONTACT-1', name: 'Claudete F. Da Silva', phone: '(48) 9 9651-3040', email: 'eduardo@ifsc.com.br' },
  { id: 'CONTACT-2', name: 'Thiago Nunes', phone: '(48) 9 9651-3040', email: 'thiago_nunes@ifsc.com.br' },
  { id: 'CONTACT-3', name: 'Lealcino Lauro Nunes', phone: '(48) 9 9651-3040', email: 'lealcino@ifsc.com.br' },
  { id: 'CONTACT-4', name: 'Diego Ramos', phone: '(48) 9 9651-3040', email: 'diegoramos@tecimob.com.br' },
];
